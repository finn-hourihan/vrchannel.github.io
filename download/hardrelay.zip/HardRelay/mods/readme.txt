Each folder here is for a different mod. Some mods have settings, in a 'settings.ini' file.

The 'settings.ini' in this folder is for the mod loader itself.

You can enable or disable each mod by editing the 'mods.txt' file. Each line corrosponds to a different mod.
To enable a mod, just insert its name, and to disable it, you just remove it.
