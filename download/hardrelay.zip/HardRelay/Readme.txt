hard relay
https://www.vrchannel.online

By Finnian Hourihan
Doukutsu Monogatari by Daisuke "Pixel" Amaya
Modified tilesets and backgrounds originally by Daisuke "Pixel" Amaya



<Controls>
←→	Move
↑	Look up
↓	Interact/Look down
Z	Jump
X	Attack
W	Map


<Credits>
Programs:
Booster's Lab - Noxid
Paint.NET - Rick Brewster
SeaTone - sshsigi
Resource Hacker - Angus Johnson



Music:
Olson - Boards of Canada
Bwomp - DR.GABBA
Jazz Ass - Shifty
Dolphin Tune - Aquarius
Please Stay- Matthieu Fauborg
Saturn Skyline - optic core
Solstice - Fred P
Olson Laconic Flow Mix - beek
In Yer Face BICEP remix - 808 State

Characters:
Satoru Gojo Big Boss (you irl) : me
Yusuf : Evan Torrez
Shabazz: Arjun Singh
Dark Lord Wayne: Chance Jaffray
CINCODEMAYO: Aaron Rose
Bingo: Hazel Johns
Lilac: Hazel Johns
Piero: Mitchell Szlabowicz
Z5: me
JJBB: Joseph Saba

Testers:
Joseph Saba
Nick Diaz
Sam Owen
Nick Cervantes
Evan Torrez
Jackson Gottko
Aaron Rose


Thank you!